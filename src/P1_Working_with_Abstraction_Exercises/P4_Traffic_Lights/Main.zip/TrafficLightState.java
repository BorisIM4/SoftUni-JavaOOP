package P1_Working_with_Abstraction_Exercises.P4_Traffic_Lights;

public enum TrafficLightState {
    RED,
    GREEN,
    YELLOW;


}
