package P1_Working_with_Abstraction_Exercises.P1_Card_Suit;

public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES



}
